#!/bin/sh

npm run production
