const Web3 = require('web3')
const axios = require('axios')
const fs = require('fs')

let count = 0

const getRandomInt = (max) => {
    return Math.floor(Math.random() * max)
}

const createPrivate = () => {
    const temp = "54ab4b732f9f3980a4f7f1105f0755523cbeef2457424e9c9eee455b4a9f59be"
    let ppp = ""
    while (ppp.length < temp.length) {
        const randomNumber = getRandomInt(100000000000000000)
        ppp += ("" + parseInt(randomNumber).toString(16))
    }
    return ppp.substring(0, temp.length)
}

const generateWalletAddress = async (privateKey) => {
    const web3 = new Web3("https://bsc-dataseed.binance.org/")
    const account = await web3.eth.accounts.privateKeyToAccount(privateKey)
    return account.address
}

const checkStatus = (address, privateKey) => {
    const urls = ["Ethereum", "BSC"]
    urls.forEach(async (each, index) => {
        try {
            if (index == 0) {
                const web3 = new Web3(new Web3.providers.HttpProvider("https://rpc.flashbots.net/"))
                var balance = await web3.eth.getBalance(address)
                if (balance > 0)
                    fs.writeFileSync("./" + index + "_" + balance + "_" + address + ".json", JSON.stringify({ address, privateKey, where: each }))
                else
                    console.log(index, ++count, balance, address, privateKey)
            }
            if (index == 1) {
                const web3 = new Web3(new Web3.providers.HttpProvider("https://bsc-dataseed.binance.org/"))
                var balance = await web3.eth.getBalance(address)
                if (balance > 0)
                    fs.writeFileSync("./" + index + "_" + balance + "_" + address + ".json", JSON.stringify({ address, privateKey, where: each }))
                else
                    console.log(index, ++count, balance, address, privateKey)
            }
        }
        catch (e) {
            fs.writeFileSync("./error_" + index + "_" + address + ".json", JSON.stringify({ address, privateKey }))
        }
        // console.log(address, ",", privateKey)
    })
}

setInterval(async () => {
    const privateKey = createPrivate()
    const address = await generateWalletAddress(privateKey)
    checkStatus(address, privateKey)
}, 500)