export type SubscriptionAttributes = {
  proposal_id: string,
  user: string,
  created_at: Date
}