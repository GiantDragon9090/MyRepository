import MtvPunks from "./MTVPunks.json";
import Voting from "./Voting.json";

const abis = {
  MtvPunks: MtvPunks,
  Voting: Voting
};

export default abis;
