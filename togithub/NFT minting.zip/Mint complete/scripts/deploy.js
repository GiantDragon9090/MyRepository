// We require the Hardhat Runtime Environment explicitly here. This is optional
// but useful for running the script in a standalone fashion through `node <script>`.
//
// When running the script with `npx hardhat run <script>` you'll find the Hardhat
// Runtime Environment's members available in the global scope.
const hre = require("hardhat");

async function main() {
  // Hardhat always runs the compile task when running scripts with its command
  // line interface.
  //
  // If this script is run directly using `node` you may want to call compile
  // manually to make sure everything is compiled
  // await hre.run('compile');

  // We get the contract to deploy
  const King = await hre.ethers.getContractFactory("King");
  const king = await King.deploy("0x23c9a46731FFd0fc3C99DcB69B85200ee0Ac7051","0x2f6e16B4a6D02E247E59F4C4bB1892B8A87b79c2" ,2500000000);

  await king.deployed();

  console.log("Greeter deployed to:", king.address);
}

// We recommend this pattern to be able to use async/await everywhere
// and properly handle errors.
main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
///////////////////////////0x0555971169D868Fe2a6D20Fe4B20755a30AE813c/////0x00C04ebdEE474E9D930c4b4cEc4A0bBB1F25f723/////0x6619115F6c9936E4B84D3778E4b303756bFbb58d
///////////////////////////0xfcE41d3c71223Af81ae7720b96e70ABB563Fa598