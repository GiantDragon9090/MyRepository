const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("Greeter", function () {
  it("Should return the new greeting once it's changed", async function () {
    const King = await ethers.getContractFactory("King");
    const king = await King.deploy();
    await king.deployed();

    expect(await king.mint(1, false)).to.equal("Hello, world!");

    const setKingTx = await king.tokenURI(1);

    // wait until the transaction is mined
    await setGreetingTx.wait();

    expect(await greeter.greet()).to.equal("Hola, mundo!");
  });
});
