declare module 'markdown-escape' {
  export = (value: string) => string
}