export enum FeatureFlags {
  // Grant = 'dao-enabled-grants', @deprecateed
  // Polygon = 'dao-enabled-polygon',
  Ens = 'dao-enabled-ens',
  Delegation = 'dao-enabled-delegation',
}