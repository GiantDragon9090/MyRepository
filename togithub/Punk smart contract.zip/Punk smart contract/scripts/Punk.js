// We require the Hardhat Runtime Environment explicitly here. This is optional
// but useful for running the script in a standalone fashion through `node <script>`.
//
// When running the script with `npx hardhat run <script>` you'll find the Hardhat
// Runtime Environment's members available in the global scope.
const hre = require("hardhat");

const { ethers, upgrades } = require("hardhat");

async function main() {
  const Punk = await hre.ethers.getContractFactory("MTVPunks");
  const punk = await upgrades.deployProxy(Punk, ["0xfe4f5145f6e09952a5ba9e956ed0c25e3fa4c7f1"]);
  await punk.deployed();
  console.log("Box deployed to:", punk.address);
  console.log(await upgrades.erc1967.getImplementationAddress(punk.address));  // implementation address
}

main();
// Box deployed to: 0x55efbdEDD4c75027BCb3473e4B091c5Fa4c3F6c3
// 0xE27967F1e2c69ab116d0c1d5cfE0337DBa7ab439

// Box deployed to: 0x28Ba4021Fe07f8aD74c9d981F2D4D0612Ab29786
// 0x1Dcb2836D5F55CAe09a8C4D66dE18804b84A05Ff

// Box deployed to: 0x28Ba4021Fe07f8aD74c9d981F2D4D0612Ab29786
// 0x3f1318c31FC0EE6ab6f8e6aB1914540B600137a3///////////0xafc823d8ce6132fe1a6043cdc9dab60093c2c2e1