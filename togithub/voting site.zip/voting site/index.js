const Web3 = require('web3');
const { JsonRpcProvider } = require("@ethersproject/providers");
const { Wallet } = require("@ethersproject/wallet");
const { Contract, Signer, utils } = require("ethers");
const config = require('config');
const {getActiveProposals, finishProposal} = require('./lib/voting-api');
const _abi = require('./lib/voting-abi')

const PROPOSAL_LIFETIME = 3600 * 24 * 7 * 1000;  // 7 days
// const PROPOSAL_LIFETIME = 60 * 1 * 1000;  // 5 mins

const adminEndpoint = config.get('ADMIN_ENDPOINT');
const MTV_ORIGIN = config.get('MTV_ORIGIN');
const contractAddress = config.get('VOTING_CONTRACT')
const privateKey = config.get('PSEUDO_ADDRESS')

const provider = new JsonRpcProvider(MTV_ORIGIN);
const signer = new Wallet(privateKey, provider);
const votingContractInstance = new Contract(contractAddress, _abi, signer)

votingContractInstance.on("VotingExecuted", async (votingId, result) => {
  const _voteId = parseInt(utils.formatUnits(votingId, 0))
  await finishProposal(_voteId, result, adminEndpoint)
  console.log("Finished Proposal: ", _voteId, result)
})

const checkProposals = () => {
  getActiveProposals(adminEndpoint).then((resp) => {
    return resp.json()
  }).then((res) => {
    proposals = res.data;
    if(proposals) {
      proposals.map(async (item) => {
        const createdAt = new Date(item.created_at).getTime()
        const timeRemainig = PROPOSAL_LIFETIME - (new Date().getTime() - createdAt)
        if(timeRemainig < 0) {
          try {
            await votingContractInstance.executeVoting(item.id)
            console.log("Executed :", item.id)
          } catch(e) {
            console.log("failed to excute contract")
          }
        }
      })
    }
  })
}

checkProposals()
setInterval(() => {
  checkProposals()
}, 60000)