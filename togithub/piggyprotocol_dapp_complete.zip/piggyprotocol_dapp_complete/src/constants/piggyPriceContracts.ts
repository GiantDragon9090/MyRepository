const priceContracts: { piggyAddress: string, busdAddress: string, wbnbAddress: string, lpAddress: string } = {
  piggyAddress: '0xD6b967941aB115B5921f580698f16A0d680ea57E',
  busdAddress: '0xe9e7cea3dedca5984780bafc599bd69add087d56',
  wbnbAddress: '0xbb4cdb9cbd36b01bd1cbaebf2de08d9173bc095c',
  lpAddress: '0x0733Ab9814e897ea2f70f555670Ca3241f3cF9e5'
}

export default priceContracts