// We require the Hardhat Runtime Environment explicitly here. This is optional
// but useful for running the script in a standalone fashion through `node <script>`.
//
// When running the script with `npx hardhat run <script>` you'll find the Hardhat
// Runtime Environment's members available in the global scope.
const hre = require("hardhat");

// async function main() {
//   // Hardhat always runs the compile task when running scripts with its command
//   // line interface.
//   //
//   // If this script is run directly using `node` you may want to call compile
//   // manually to make sure everything is compiled
//   // await hre.run('compile');

//   // We get the contract to deploy
//   const King = await hre.ethers.getContractFactory("King");
//   const king = await King.deploy();

//   await king.deployed();

//   console.log("Greeter deployed to:", king.address);
// }

// // We recommend this pattern to be able to use async/await everywhere
// // and properly handle errors.
// main().catch((error) => {
//   console.error(error);
//   process.exitCode = 1;
// });
// //////////////////////////0x7620752890D9C8b67387eC864569d348787EAcAC

// scripts/create-box.js
const { ethers, upgrades } = require("hardhat");

async function main() {
  const King1 = await hre.ethers.getContractFactory("MTVPunks");
  const king = await upgrades.upgradeProxy("0x28Ba4021Fe07f8aD74c9d981F2D4D0612Ab29786",King1);
  await king.deployed();
  console.log("Box deployed to:", king.address);
  console.log(await upgrades.erc1967.getImplementationAddress(king.address));
}

main();