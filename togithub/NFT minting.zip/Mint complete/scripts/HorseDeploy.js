// We require the Hardhat Runtime Environment explicitly here. This is optional
// but useful for running the script in a standalone fashion through `node <script>`.
//
// When running the script with `npx hardhat run <script>` you'll find the Hardhat
// Runtime Environment's members available in the global scope.
const hre = require("hardhat");

async function main() {
  // Hardhat always runs the compile task when running scripts with its command
  // line interface.
  //
  // If this script is run directly using `node` you may want to call compile
  // manually to make sure everything is compiled
  // await hre.run('compile');

  // We get the contract to deploy
  const Horse = await hre.ethers.getContractFactory("Horse");
  const horse = await Horse.deploy("0xfcE41d3c71223Af81ae7720b96e70ABB563Fa598","0x23c9a46731FFd0fc3C99DcB69B85200ee0Ac7051");

  await horse.deployed();

  console.log("Horse deployed to:", horse.address);
}

// We recommend this pattern to be able to use async/await everywhere
// and properly handle errors.
main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
///////////////////////////0xB91d1f1AB1d5358A482Fb10AE825C44976f1dCC5/////0x8b4A69671A7BEECF921400c360dE28658054688d
//////////0x53dfb95106A87BfCa3319dfa23423ec38a7a7C3d