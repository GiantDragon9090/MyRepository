/* eslint-disable @typescript-eslint/camelcase */
import { MigrationBuilder, ColumnDefinitions } from 'node-pg-migrate';

export async function up(): Promise<void> {
}

export async function down(): Promise<void> {
}
