/*
SQLyog Ultimate v13.1.1 (64 bit)
MySQL - 10.4.14-MariaDB : Database - trust_vc
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`trust_vc` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `trust_vc`;

/*Table structure for table `invest` */

DROP TABLE IF EXISTS `invest`;

CREATE TABLE `invest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `token_id` int(11) DEFAULT NULL,
  `amount` bigint(20) DEFAULT NULL,
  `designation` varchar(100) DEFAULT NULL,
  `investcompany` varchar(100) DEFAULT NULL,
  `token_amount` double DEFAULT NULL,
  `regdate` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

/*Data for the table `invest` */

insert  into `invest`(`id`,`user_id`,`token_id`,`amount`,`designation`,`investcompany`,`token_amount`,`regdate`) values 
(14,4,1,22000,'2','2',1,'2022-06-16'),
(15,6,1839,22000,'Try','Invest',100,'2022-06-16'),
(12,4,825,232,'1','1',232,'2022-05-16'),
(9,4,1839,22000,'blockchain','xoxoz',100,'2022-06-16'),
(13,4,825,11,'1','1',11,'2022-06-16'),
(16,4,14938,10,'deng','company',200,'2022-06-16');

/*Table structure for table `token` */

DROP TABLE IF EXISTS `token`;

CREATE TABLE `token` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `logo` text DEFAULT NULL,
  `symbol` varchar(20) DEFAULT NULL,
  `slug` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `platform` varchar(30) DEFAULT NULL,
  `type` int(11) DEFAULT 0,
  `cmc_id` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14942 DEFAULT CHARSET=utf8;

/*Data for the table `token` */

insert  into `token`(`id`,`name`,`logo`,`symbol`,`slug`,`address`,`description`,`platform`,`type`,`cmc_id`) values 
(1,'Bitcoin','https://s2.coinmarketcap.com/static/img/coins/64x64/1.png','BTC','bitcoin',NULL,'Bitcoin (BTC) is a cryptocurrency . Users are able to generate BTC through the process of mining. Bitcoin has a current supply of 19,068,793. The last known price of Bitcoin is 22,074.74483048 USD and is up 4.03 over the last 24 hours. It is currently trading on 9533 active market(s) with $52,463,115,228.82 traded over the last 24 hours. More information can be found at https://bitcoin.org/.',NULL,0,1),
(1839,'BNB','https://s2.coinmarketcap.com/static/img/coins/64x64/1839.png','BNB','bnb',NULL,'BNB (BNB) is a cryptocurrency . BNB has a current supply of 163,276,974.63. The last known price of BNB is 226.77435853 USD and is up 6.73 over the last 24 hours. It is currently trading on 953 active market(s) with $2,147,470,360.14 traded over the last 24 hours. More information can be found at https://www.binance.com/.',NULL,0,1839),
(3408,'USD Coin','https://s2.coinmarketcap.com/static/img/coins/64x64/3408.png','USDC','usd-coin','0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48','USD Coin (USDC) is a cryptocurrency and operates on the Ethereum platform. USD Coin has a current supply of 54,221,405,996.25045. The last known price of USD Coin is 1.00003253 USD and is down -0.04 over the last 24 hours. It is currently trading on 4438 active market(s) with $10,277,702,451.57 traded over the last 24 hours. More information can be found at https://www.centre.io/usdc.','Ethereum',0,3408),
(825,'Tether','https://s2.coinmarketcap.com/static/img/coins/64x64/825.png','USDT','tether','0xdac17f958d2ee523a2206206994597c13d831ec7','Tether (USDT) is a cryptocurrency and operates on the Ethereum platform. Tether has a current supply of 79,710,622,658.21005 with 70,038,816,028.79582 in circulation. The last known price of Tether is 0.99896994 USD and is up 0.04 over the last 24 hours. It is currently trading on 34744 active market(s) with $85,929,130,687.60 traded over the last 24 hours. More information can be found at https://tether.to.','Ethereum',0,825),
(2010,'Cardano','https://s2.coinmarketcap.com/static/img/coins/64x64/2010.png','ADA','cardano','0x3ee2200efb3400fabb9aacf31297cbdd1d435d47','Cardano (ADA) is a cryptocurrency launched in 2017. Users are able to generate ADA through the process of mining. Cardano has a current supply of 34,277,702,081.605 with 33,934,048,405.593 in circulation. The last known price of Cardano is 0.51254039 USD and is up 10.33 over the last 24 hours. It is currently trading on 457 active market(s) with $2,238,816,609.80 traded over the last 24 hours. More information can be found at https://www.cardano.org.','BNB Smart Chain (BEP20)',0,2010),
(4687,'Binance USD','https://s2.coinmarketcap.com/static/img/coins/64x64/4687.png','BUSD','binance-usd','BUSD-BD1','Binance USD (BUSD) is a cryptocurrency and operates on the BNB Beacon Chain (BEP2) platform. Binance USD has a current supply of 17,635,721,150.709255. The last known price of Binance USD is 1.00003854 USD and is down -0.08 over the last 24 hours. It is currently trading on 3843 active market(s) with $7,917,135,936.38 traded over the last 24 hours. More information can be found at https://www.binance.com/en/busd.','BNB Beacon Chain (BEP2)',0,4687),
(52,'XRP','https://s2.coinmarketcap.com/static/img/coins/64x64/52.png','XRP','xrp','0x1d2f0da169ceb9fc7b3144628db156f3f6c60dbe','XRP (XRP) is a cryptocurrency . XRP has a current supply of 99,989,535,142 with 48,343,101,197 in circulation. The last known price of XRP is 0.33547862 USD and is up 9.95 over the last 24 hours. It is currently trading on 739 active market(s) with $2,132,179,493.50 traded over the last 24 hours. More information can be found at https://xrpl.org/.','BNB Smart Chain (BEP20)',0,52),
(5426,'Solana','https://s2.coinmarketcap.com/static/img/coins/64x64/5426.png','SOL','solana',NULL,'Solana (SOL) is a cryptocurrency launched in 2020. Solana has a current supply of 511,616,946.142289 with 342,216,527.94639075 in circulation. The last known price of Solana is 33.72150525 USD and is up 19.33 over the last 24 hours. It is currently trading on 333 active market(s) with $2,557,715,360.38 traded over the last 24 hours. More information can be found at https://solana.com.',NULL,1,5426),
(11532,'Arsenal Fan Token','https://s2.coinmarketcap.com/static/img/coins/64x64/11532.png','AFC','arsenal-fan-token',NULL,'Arsenal Fan Token (AFC) is a cryptocurrency . Arsenal Fan Token has a current supply of 40,000,000 with 2,003,867 in circulation. The last known price of Arsenal Fan Token is 1.46974333 USD and is up 5.12 over the last 24 hours. It is currently trading on 4 active market(s) with $499,888.23 traded over the last 24 hours. More information can be found at https://www.arsenal.com/news/afc-fan-token-everything-you-need-know.',NULL,1,11532),
(14932,'CyOp Protocol','https://s2.coinmarketcap.com/static/img/coins/64x64/14932.png','CYOP','cyop-protocol','0xddac9c604ba6bc4acec0fbb485b83f390ecf2f31','CyOp Protocol (CYOP) is a cryptocurrency and operates on the Ethereum platform. CyOp Protocol has a current supply of 0. The last known price of CyOp Protocol is 0.00000001 USD and is up 27.98 over the last 24 hours. It is currently trading on 2 active market(s) with $39,471.11 traded over the last 24 hours. More information can be found at https://cyop.io/.','Ethereum',1,14932),
(14938,'Dice Token','https://res.cloudinary.com/dqt9ksuhq/image/upload/v1655398378/inv/token/sxz6yw5r1nspp1ja4qgc.jpg','DiCe','394293','0x323r3234','93fjdfjsj','ojdfoif',1,0),
(14937,'Force For Fast','https://s2.coinmarketcap.com/static/img/coins/64x64/6448.png','FFF','force-for-fast','0x22f098F08c4eda4bE4ad6B4ba59866F3E98CEF92','Force For Fast (FFF) is a cryptocurrency and operates on the Ethereum platform. Force For Fast has a current supply of 0. The last known price of Force For Fast is 0.00017021 USD and is down -17.27 over the last 24 hours. It is currently trading on 2 active market(s) with $77.02 traded over the last 24 hours. More information can be found at http://www.forceforfast.com/.','Ethereum',1,6448);

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `photo` text DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `isAdmin` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

/*Data for the table `user` */

insert  into `user`(`id`,`name`,`company`,`email`,`mobile`,`photo`,`password`,`isAdmin`) values 
(1,'Gito Murata','Free','giantdragon9090@gmail.com','3423423','https://res.cloudinary.com/dqt9ksuhq/image/upload/v1655338379/inv/user/fh1aycqw55brruufvaf2.jpg','e10adc3949ba59abbe56e057f20f883e',1),
(4,'Jen','ww','abc@bcd','34234','https://res.cloudinary.com/dqt9ksuhq/image/upload/v1655322882/inv/user/vsmviy8lipvzfqbygc61.jpg','6512bd43d9caa6e02c990b0a82652dca',0),
(6,'Jason','Free','gdd@fine','232094','https://res.cloudinary.com/dqt9ksuhq/image/upload/v1655369779/inv/user/ool8edztagcp9xfjgijs.png','ac05c7d8f4406c971085f947e43ef730',0);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
