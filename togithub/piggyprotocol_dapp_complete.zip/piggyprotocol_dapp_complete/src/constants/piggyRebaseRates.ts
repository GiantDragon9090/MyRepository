const rebaseRates: { rebaseRate1: number, rebaseRate2: number, rebaseRate3: number, rebaseRate4: number } = {
  rebaseRate1: 0.0002461,
  rebaseRate2: 0.0000322,
  rebaseRate3: 0.0000035,
  rebaseRate4: 0.0000003
}

export default rebaseRates